import sys
from PySide.QtCore import *
from PySide.QtGui import *

class Form(QDialog):

    def __init__(self, parent=None):
        super(Form, self).__init__(parent)

# Code to show the list of checkboxs with labels
#         layout = QVBoxLayout()
        
#         self.checks = []
#         for i in xrange(100):
#             c = QCheckBox("Option %i" % i)
#             layout.addWidget(c)
#             self.checks.append(c)

        # self.setLayout(layout)

        # Our main window will be a QListView
        list = QListView()
        list.setWindowTitle('Example List')
        list.setMinimumSize(2, 1)
        list.setAutoScroll
        
        # Create an empty model for the list's data
        model = QStandardItemModel(list)
        
        layout = QVBoxLayout()
        layout.addWidget(list)

        # Add some textual items
        foods = [
            'Cookie dough', # Must be store-bought
            'Hummus', # Must be homemade
            'Spaghetti', # Must be saucy
            'Dal makhani', # Must be spicy
            'Chocolate whipped cream' # Must be plentiful
            'Cookie dough', # Must be store-bought
            'Hummus', # Must be homemade
            'Spaghetti', # Must be saucy
            'Dal makhani', # Must be spicy
            'Chocolate whipped cream' # Must be plentiful            
            'Cookie dough', # Must be store-bought
            'Hummus', # Must be homemade
            'Spaghetti', # Must be saucy
            'Dal makhani', # Must be spicy
            'Chocolate whipped cream' # Must be plentiful            
            'Cookie dough', # Must be store-bought
            'Hummus', # Must be homemade
            'Spaghetti', # Must be saucy
            'Dal makhani', # Must be spicy
            'Chocolate whipped cream' # Must be plentiful
        ]
        
        for food in foods:
            # create an item with a caption
            item = QStandardItem(food)

            # add a checkbox to it
            # item.setCheckable(True)
        
            # Add the item to the model
            model.appendRow(item)
        
        # Apply the model to the list view
        list.setModel(model)
        self.setLayout(layout)
app = QApplication(sys.argv)
form = Form()
form.show()
app.exec_()