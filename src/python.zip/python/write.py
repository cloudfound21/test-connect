# import os
# with open('text.txt', 'w') as my_own:
#     my_own.write("I'm the first line of the file!\n")
#     my_own.write("I'm the second line.\n")
#     my_own.write("Third line here, boss.\n")

# print(os.listdir(os.getcwd()))  # Shows the list of files in the directory now

# my_file = open("text.txt", "r")

# print(my_file.readline())
# print(my_file.readline())
# print(my_file.readline())

# my_file.close()

import re

mystr = 'This is a string, with words!'
# wordList = re.sub("[^\\w]", " ",  mystr).split()
wordList = mystr.split()
print(wordList)