import sys
from PySide.QtCore import *
from PySide.QtGui import *

from queryGUI import *

class MainWindow(QMainWindow, Ui_mainApp):

    def __init__(self, parent=None):
        super(MainWindow, self).__init__(parent)
        ui = Ui_mainApp()
        ui.setupUi(self)
        
        # populate the listView for the list of tables        
        ui.listView.setModel(self.populate_table_list(ui.listView))

        ui.searchTable.textEdited.connect(on_text_edited)
        
    def on_text_edited(self, text):
        pass

    # def get_table_name(self):
    def populate_table_list(self, listView): 
        # Create an empty model for the list's data
        model = QStandardItemModel(listView)
        
        with open("tables.txt") as f:
            for table in f:

                # Create an item with a caption
                item = QStandardItem(table.rstrip('\n'))
            
                # # Add a checkbox to it
                # item.setCheckable(True)
            
                # Add the item to the model
                model.appendRow(item)  

        return model

    

app =  QApplication(sys.argv)
w = MainWindow()
w.show()
app.exec_()