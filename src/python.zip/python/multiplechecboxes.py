import sys
from PySide.QtGui import *
from PySide.QtCore import *

class Window(QWidget):
    def __init__(self):
        QWidget.__init__(self)

        layout = QVBoxLayout()
        self.checks = []
        for i in xrange(5):
            c = QCheckBox("Option %i" % i)
            layout.addWidget(c)
            # self.checks.append(c)

        self.setLayout(layout)

if __name__ == '__main__':
    app = QApplication(sys.argv)

    w = Window()
    w.show()

    app.exec_()