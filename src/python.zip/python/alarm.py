from PySide.QtCore import *
from PySide.QtGui import *

import sys

class Form(QDialog):

    def __init__(self, parent=None):
        super(Form, self).__init__(parent)

        # define a widget
        self.resultsInput = QLineEdit("Enter the text to be searched")

        # choose a layout for your application window
        layout = QVBoxLayout()

        # add your widget to the window
        layout.addWidget(self.resultsInput)

        # set the layout to the current application
        self.setLayout(layout)
        # select all the text so that you can start typing without the need to delete text
        self.resultsInput.selectAll()
        self.resultsInput.setFocus()
        
        self.resultsInput.returnPressed.connect(self.compute)

    def compute(self):
        print("nothing much")
        return QLineEdit("Congrats! you have successfully pressed enter")

app = QApplication(sys.argv)
form = Form()
form.show()
app.exec_()